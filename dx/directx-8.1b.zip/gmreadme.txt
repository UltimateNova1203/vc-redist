-------------------------------------------------------------------------
GMREADME.TXT
------------

The GM.DLS file contains the Roland SoundCanvas Sound Set which is 
protected under the following copyright: 
Roland GS Sound Set/Microsoft (P) 1996 Roland Corporation U.S.  
The Roland SoundCanvas Sound Set is licensed under Microsoft's 
End User License Agreement for use with Microsoft operating 
system products only.  All other uses require a separate written 
license from Roland.

-------------------------------------------------------------------------
